<div class="gdsr-widget-controls">
<?php include(STARRATING_PATH.'widgets/comments/part_basic.php'); ?>
<?php include(STARRATING_PATH.'widgets/comments/part_filter.php'); ?>
<?php include(STARRATING_PATH.'widgets/comments/part_image.php'); ?>
<?php include(STARRATING_PATH.'widgets/comments/part_stars.php'); ?>
</div>
<input type="hidden" id="gdstarr-submit" name="<?php echo $wpfn; ?>[submit]" value="1" />
